#!Python 10  k-means algorithm
import string
import time
Data1 = [ ["cena",'zniżka'],
 [1, 13, 20, 41],
 [2, 12, 19, 72],
 [3, 12, 21, 7],
 [4, 12, 20, 37],
 [5, 10, 18, 8],
 [6, 10, 21, 22],
 [7, -11, 4, 84],
 [8, 1, 23, 9],
 [9, 5, 18, 63],
 [10, -5, 10, 13],
 [11, 0, 15, 11],
 [12, 11.3, 13.2, 66],
 [13, 22, 29, 22],
 [14, 25, 21, 20],
 [15, 20, 30, 59],
 [16, 24, 20, 61],
 [17, 20, 32, 37],
 [18, 20, 19, 13],
 [19, 16, 23, 83],
 [20, 16, 24, 89],
 [21, 14, 29, 63],
 [22, 17, 29, 17],
 [23, 15, 28, 9],
 [24, 16, 27, 6],
 [25, 16, 22, 65],
 [26, 12, 22, 75],
 [27, 18, 32, 7],
 [28, 14, 23, 39],
 [29, 20, 17, 9],
 [30, 16, 18, 25],
 [31, 15, 21, 23]]
Data = [["cena",'zniżka'],
        [1,1],
        [1,3],
        [10,1],
        [12,2],
        [1,13],
        [3,16],
        [4,11]
]

##        (X,X,X,X,X), (X,X,X,X,X,X) PUNKTY BEZ ETYKIET
     #            ETYKIETY PODAJE JAKO K : A,B,C
     #      DO PIERWSZYCH PUNKTÓW O ILE  K> ILOSC PUNKTÓW

#       KROKI :
        #1   PRZYPISANIE ETYKIET DO 3 LOSOWYCH PUNKTÓW
        #2   PUNKTY BIRE JAKO STAŁE I LICZE DYSTANSE DO KAŻDEGO INNE PUNKTU Z TYM ŻE PKT SAM DO SIEBIE MA 0 DYSTANS
        #3   (KLASA 0[] 1[],2[])  DYSTANSE   [[]
        #                             []
        #                             []]

# będzie jedna etykieta dla wszystkich punktów
# przypisanie etykiet do grup :
# jak zapisać etykietę  na krotce -1 jest etykietą
# (x,x,x,klasa)
# punkty muszą być abstrakcyjne i tymczasowe
# stworzenie macierzy gdzie klasa to jedna więcej kolumna  dla każdej klasy

from math import sqrt
def sumy_odwrotnosci_metryka(added_point, distance_data):
    if len(added_point)!= len(distance_data):
        raise  Exception(f"nieodpowiednie dystane dla punktów miedzy sobą {len(added_point)}, {len(distance_data)} ")
    suma = [(e1-e2)**2 for e1,e2 in zip(added_point,distance_data)]
    #return sum(suma)
    return round(sqrt(sum(suma)),4)

# globalne bo tu są klasy dla k punktów
Etykiety = [x for x in string.ascii_uppercase]
def get_centers(one_data,Etykieta,i=0):
    return list(one_data)+[Etykieta]
def awailable(Data,k):
    if len(Data)<k:
        raise Exception("k-count of clusters must be < length of data")
    return len(Data)>=k  and type(Data[0]) is list


def new_center_set(Data,etykiety):
    etykiety = [x[:][-1] for x in etykiety]
    i = 0
    centers = []
    for point in Data:
        number_oof_points = len(point)
        suma = [sum(points_data)/number_oof_points for points_data in zip(*point)]
        center = suma+[etykiety[i]]
        centers.append(center)
        i+=1
    return centers


def absolute_error(current_centers, previous_centers):
    # current_centers i previous_centers powinny być listami o tej samej strukturze
    total_error = 0
    count = 0

    for curr, prev in zip(current_centers, previous_centers):
        for c, p in zip(curr[:-1], prev[:-1]):  # Pomijamy etykiety
            total_error += abs(c - p)
            count += 1

    # Obliczamy średni błąd bezwzględny
    mean_absolute_error = total_error / count if count != 0 else 0
    print(mean_absolute_error)
    return mean_absolute_error>1.2


def check_groups_stability(previous_groups, current_groups):
    if len(previous_groups) != len(current_groups):
        return False  # Grupy mają różną liczbę elementów


    for prev_group, curr_group in zip(previous_groups, current_groups):

        if sorted(prev_group) != sorted(curr_group):
            return False  # Grupa zmieniła skład, kontynuujemy iteracje

    return True  # Grupy są stabilne, można zakończyć algorytm

def draw_with_etykiets_data_points(groups,centers):  #  data[[x,y....],[],[],[],], centers[[X,Y,...,A],[X,Y,....,B],[X,Y,....,C]]
    # ([[1, 13], [2, 12], [3, 12], [4, 12], [5, 10], [6, 10], [7, -11], [8, 1], [9, 5], [10, -5], [11, 0], [12, 11.3],
    #   [13, 22], [14, 25], [15, 20], [16, 24], [17, 20], [18, 20], [19, 16], [20, 16], [21, 14], [22, 17], [23, 15],
    #   [24, 16], [25, 16], [26, 12], [27, 18], [28, 14], [29, 20], [30, 16], [31, 15]],
    #  [[1, 13, 'A'], [2, 12, 'B'], [17, 13, 'C']])
    from matplotlib import pyplot as plt
    if len(groups)!= len(centers):
        raise Exception("One of data is not long enought len(groups)!=len(centers)")
    fig,ax = plt.subplots()
    for group,center in zip(groups,centers):
        x = [point[0] for point in group]
        y = [point[1] for point in group]
        plt.scatter(x, y,  label=center[-1], s=30)
        for i in range(len(x)):
            ax.annotate(center[-1], (x[i], y[i]), textcoords="offset points", xytext=(0, 4), ha='center')

        plt.scatter(center[0],center[1],marker="*",label= center[-1],s=100)
    plt.grid()
    plt.show()
    time.sleep(1)

heads = 0
def initilaize(Data,k,i=0,cluster_center=None,groups_before= None):
    global heads
    counting =  awailable(Data,k)
    if counting and k==1:
        return  [x+[Etykiety[i]] for x in Data[1:]]
    else:
        Data_etyk = []
        groups= []
        if cluster_center==None :
            cluster_center=[]
            for index in range(k):
                # Calculate center for each cluster and add to Data_etyk
                cluster_center = get_centers(Data[index], Etykiety[index])
                Data_etyk.append(cluster_center)
                groups.append([])

        else:
            Data_etyk = [x for x in cluster_center]
            groups = [[] for x in cluster_center]
        # for index  in range(k):
        #     # Calculate center for each cluster and add to Data_etyk
        #     cluster_center = get_centers(Data[index], Etykiety[index])
        #     Data_etyk.append(cluster_center)
        #     groups.append([])


        for tp in Data:
            distance_for_current_center = []
            for center in Data_etyk:
                distance_for_current_center.append(sumy_odwrotnosci_metryka(center[:-1], tp))

            min_distance_point = min(distance_for_current_center)
            index = distance_for_current_center.index(min_distance_point)
            groups[index].append(tp)


    #draw_with_etykiets_data_points(groups,Data_etyk)
    new_centers = new_center_set(groups,Data_etyk)
    import collections
    heads += 1
    flag1=True
    flag2 = absolute_error(Data_etyk, new_centers)
    if heads >=2:
        flag1 =check_groups_stability(groups_before,groups)

    ### petla do poprawy
    for i in range(len(Data_etyk)):
        print(f"before : {Data_etyk[i]} after:{new_centers[i]}")
        if flag1 or flag2:
           if heads <=16:
                initilaize(Data, k, cluster_center=new_centers,groups_before=groups)
    draw_with_etykiets_data_points(groups, Data_etyk)
    return Data,new_centers

print((initilaize(Data[1:],3)))

# assert (initilaize(Data,1,i=0)) == [(3, 4, 5, 'A'), (1, 6, 8, 'A'), (4, 4, 4, 'A'), (21, 22, 32, 'A'), (21, 19, 0, 'A'), (22, 21, 0, 'A')]

#assert (initilaize(Data[0:2],2))==True
#assert (initilaize(Data[0:2],3))==False
#assert (initilaize(Data[0],1))==False
#assert (initilaize(Data[0:2],1))==True